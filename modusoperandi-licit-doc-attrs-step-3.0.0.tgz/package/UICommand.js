import { Transaction } from 'prosemirror-state';
export const EventType = {
    CLICK: 'mouseup',
    MOUSEENTER: 'mouseenter',
};
export class UICommand {
    static EventType = EventType;
    // eslint-disable-next-line sonarjs/public-static-readonly
    static theme;
    _editor = null;
    // Getter for the editor instance
    get editor() {
        return this._editor;
    }
    // Setter for the editor instance
    set editor(editor) {
        this._editor = editor;
    }
    shouldRespondToUIEvent = (e) => {
        return e.type === UICommand.EventType.CLICK;
    };
    renderLabel(_state) {
        return null;
    }
    isActive(_state) {
        return true;
    }
    isEnabled = (state, view) => {
        return this.dryRun(state, view);
    };
    dryRun = (state, view) => {
        const fnProxy = typeof window !== 'undefined' && window['Proxy'];
        const dryRunState = fnProxy
            ? new fnProxy(state, {
                get: this.dryRunEditorStateProxyGetter,
                set: this.dryRunEditorStateProxySetter,
            })
            : state;
        return this.execute(dryRunState, undefined, view, null);
    };
    dryRunEditorStateProxyGetter = (state, propKey) => {
        const val = state[propKey];
        if (propKey === 'tr' && val instanceof Transaction) {
            return val.setMeta('dryrun', true);
        }
        return val;
    };
    dryRunEditorStateProxySetter = (state, propKey, propValue) => {
        state[propKey] = propValue;
        // Indicate success
        return true;
    };
    execute = (state, dispatch, view, event) => {
        this.waitForUserInput(state, dispatch, view, event)
            .then((inputs) => {
            this.executeWithUserInput(state, dispatch, view, inputs);
        })
            .catch((error) => {
            console.error(error);
        });
        return false;
    };
}
