import { Plugin, EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
export type UserKeyCommand = (state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView) => boolean;
export type UserKeyMap = {
    [key: string]: UserKeyCommand;
};
export declare function makeKeyMap(description: string, windows: string, mac: string, common?: string): any;
export declare function makeKeyMapWithCommon(description: string, common: string): any;
export declare function setPluginKey(plugin: Plugin, key: string): Plugin;
export declare function createKeyMapPlugin(pluginKeyMap: any, name: string): Plugin;
