import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { applyMark, updateMarksAttrs } from './applyMark';
import { isTextStyleMarkCommandEnabled } from './isTextStyleMarkCommandEnabled';
import { TextSelection } from 'prosemirror-state';
import { MARK_FONT_SIZE } from './MarkNames';
function setFontSize(tr, state, schema, pt, isCustomStyleApplied) {
    const markType = schema.marks[MARK_FONT_SIZE];
    if (!markType) {
        return tr;
    }
    const attrs = pt ? { pt: pt, overridden: !isCustomStyleApplied } : null;
    tr = applyMark(tr, schema, markType, attrs, isCustomStyleApplied);
    if (undefined === isCustomStyleApplied) {
        updateMarksAttrs(markType, tr, state, pt);
    }
    return tr;
}
export class FontSizeCommand extends UICommand {
    _popUp = null;
    _pt = 0;
    constructor(pt) {
        super();
        this._pt = pt;
    }
    isEnabled = (state) => {
        return isTextStyleMarkCommandEnabled(state, MARK_FONT_SIZE);
    };
    waitForUserInput = (_state, _dispatch, _view, _event) => {
        return Promise.resolve(undefined);
    };
    executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
        return false;
    };
    cancel() {
        return null;
    }
    execute = (state, dispatch
    // view?: EditorView
    ) => {
        const { schema } = state;
        // commnted selection because selection removes the storedMarks;
        // {selection}
        // const tr = setFontSize(state.tr.setSelection(selection), schema, this._pt);
        const tr = setFontSize(state.tr, state, schema, this._pt);
        if (tr.docChanged || tr.storedMarksSet) {
            // If selection is empty, the color is added to `storedMarks`, which
            // works like `toggleMark`
            // (see https://prosemirror.net/docs/ref/#commands.toggleMark).
            dispatch?.(tr);
            return true;
        }
        return false;
    };
    // [FS] IRAD-1087 2020-10-01
    // Method to execute custom styling implementation of font size
    executeCustom = (state, tr, from, to) => {
        const { schema } = state;
        tr = setFontSize(tr.setSelection(TextSelection.create(tr.doc, from, to)), state, schema, this._pt, true);
        return tr;
    };
    executeCustomStyleForTable = (state, tr, from, to) => {
        const { schema } = state;
        tr = setFontSize(tr.setSelection(TextSelection.create(tr.doc, from, to)), state, schema, this._pt, true);
        return tr;
    };
    isActive() {
        return true;
    }
    renderLabel() {
        return null;
    }
}
