import { Node } from 'prosemirror-model';
export declare function isInsideListItem(doc: Node, pos: number): boolean;
