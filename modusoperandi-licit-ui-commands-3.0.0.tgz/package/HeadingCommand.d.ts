import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import * as React from 'react';
export declare class HeadingCommand extends UICommand {
    _level: number;
    constructor(level: number);
    isActive: (_state: EditorState) => boolean;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    renderLabel: () => any;
    executeCustom: (_state: EditorState, tr: Transform) => Transform;
    executeCustomStyleForTable: (_state: EditorState, tr: Transform, _from: number, _to: number) => Transform;
}
