import { Transform } from 'prosemirror-transform';
import { Transaction } from 'prosemirror-state';
export declare function consolidateListNodes(tr: Transaction): Transform;
