import { EditorState } from 'prosemirror-state';
export declare function isTextStyleMarkCommandEnabled(state: EditorState, markName: string): boolean;
