export type HTMLStyles = {
    align?: string;
    boldNumbering?: boolean;
    boldPartial?: boolean;
    boldSentence?: boolean;
    fontName?: string;
    fontSize?: string;
    strong?: boolean;
    em?: boolean;
    underline?: boolean;
    color?: string;
    textHighlight?: string;
    hasNumbering?: boolean;
    hasBullet?: boolean;
    paragraphSpacingAfter?: string;
    paragraphSpacingBefore?: string;
    styleLevel?: number;
    bulletLevel?: string | boolean;
    lineHeight?: string;
    isLevelbased?: boolean;
    indent?: string;
    nextLineStyleName?: string;
    toc?: boolean;
    isHidden?: boolean;
    strike?: string;
    isList?: boolean;
    prefixValue?: string;
};
export type Style = {
    /**
     * Name of the style. Case insensitive value must be unique.
     */
    styleName: string;
    mode?: number;
    description?: string;
    styles?: HTMLStyles;
    docType?: string;
};
export declare function setRuntime(runtime: any): void;
export declare abstract class RuntimeService {
    private static runtime;
    static get Runtime(): any;
    static set Runtime(runtime: any);
}
export declare function getStyleByName(styleName: string): Style;
export declare function setCustomStyles(styleList?: Style[]): void;
