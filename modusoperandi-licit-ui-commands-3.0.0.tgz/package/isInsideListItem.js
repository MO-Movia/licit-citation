import { LIST_ITEM } from './NodeNames';
export function isInsideListItem(doc, pos) {
    if (doc.nodeSize < 2 || pos < 2) {
        return false;
    }
    const prevNode = doc.nodeAt(pos - 1);
    return prevNode && prevNode.type.name === LIST_ITEM;
}
