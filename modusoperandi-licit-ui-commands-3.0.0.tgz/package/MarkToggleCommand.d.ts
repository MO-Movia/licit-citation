import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import * as React from 'react';
export declare class MarkToggleCommand extends UICommand {
    _markName: string;
    doUpdate: boolean;
    constructor(markName: string);
    isActive: (state: EditorState) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
    executeCustom: (state: EditorState, tr: Transform, posfrom: number, posto: number) => any;
    executeCustomStyleForTable: (state: EditorState, tr: Transform, from: number, to: number) => any;
    renderLabel(): any;
}
export declare function toggleCustomStyle(markType: any, attrs: any, state: any, tr: any, posfrom: number, posto: number): any;
