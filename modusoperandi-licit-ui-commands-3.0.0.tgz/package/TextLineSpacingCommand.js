import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { BLOCKQUOTE, HEADING, LIST_ITEM, PARAGRAPH } from './NodeNames';
import { DOUBLE_LINE_SPACING, SINGLE_LINE_SPACING, LINE_SPACING_115, LINE_SPACING_150, } from './ui/toCSSLineSpacing';
import { getSelectionRange, isColumnCellSelected, getSelectedCellPositions } from './isNodeSelectionForNodeType';
export function setTextLineSpacing(tr, schema, lineSpacing) {
    const { selection, doc } = tr;
    if (!selection || !doc) {
        return tr;
    }
    const paragraph = schema.nodes[PARAGRAPH];
    const heading = schema.nodes[HEADING];
    const listItem = schema.nodes[LIST_ITEM];
    const blockquote = schema.nodes[BLOCKQUOTE];
    if (!paragraph && !heading && !listItem && !blockquote) {
        return tr;
    }
    const tasks = [];
    const lineSpacingValue = lineSpacing || null;
    const allowedNodeTypes = new Set([blockquote, heading, listItem, paragraph]);
    if (isColumnCellSelected(selection)) {
        const positions = getSelectedCellPositions(selection);
        if (positions.length > 0) {
            positions.forEach(originalPos => {
                const pos = originalPos + 1;
                const node = tr.doc.nodeAt(pos);
                if (!node)
                    return;
                const nodeType = node.type;
                if (allowedNodeTypes.has(nodeType)) {
                    const lineSpacing = node.attrs.lineSpacing ?? null;
                    if (lineSpacing !== lineSpacingValue) {
                        tasks.push({
                            node,
                            pos,
                            nodeType,
                        });
                    }
                }
            });
        }
    }
    else {
        const { from, to } = getSelectionRange(selection);
        doc.nodesBetween(from, to, (node, pos, _parentNode) => {
            const nodeType = node.type;
            if (allowedNodeTypes.has(nodeType)) {
                const lineSpacing = node.attrs.lineSpacing || null;
                if (lineSpacing !== lineSpacingValue) {
                    tasks.push({
                        node,
                        pos,
                        nodeType,
                    });
                }
                return nodeType === listItem;
            }
            return true;
        });
    }
    if (!tasks.length) {
        return tr;
    }
    tasks.forEach((job) => {
        const { node, pos, nodeType } = job;
        let { attrs } = node;
        if (lineSpacingValue) {
            attrs = {
                ...attrs,
                lineSpacing: lineSpacingValue,
                overriddenLineSpacing: true,
                overriddenLineSpacingValue: lineSpacing
            };
        }
        else {
            const isOverriddenLineSpacing = attrs.overriddenLineSpacing ?? null;
            attrs = {
                ...attrs,
                lineSpacing: isOverriddenLineSpacing ? attrs.lineSpacing : SINGLE_LINE_SPACING,
                overriddenLineSpacing: isOverriddenLineSpacing ? attrs.overriddenLineSpacing : null,
                overriddenLineSpacingValue: isOverriddenLineSpacing ? attrs.overriddenLineSpacingValue : null
            };
        }
        tr = tr.setNodeMarkup(pos, nodeType, attrs, node.marks);
    });
    return tr;
}
function createGroup() {
    const group = {
        Single: new TextLineSpacingCommand(SINGLE_LINE_SPACING),
        '1.15': new TextLineSpacingCommand(LINE_SPACING_115),
        '1.5': new TextLineSpacingCommand(LINE_SPACING_150),
        Double: new TextLineSpacingCommand(DOUBLE_LINE_SPACING),
    };
    return [group];
}
export class TextLineSpacingCommand extends UICommand {
    _lineSpacing;
    static createGroup = createGroup;
    constructor(lineSpacing) {
        super();
        this._lineSpacing = lineSpacing;
    }
    isActive = (state) => {
        const { selection, doc, schema } = state;
        const { from, to } = selection;
        const paragraph = schema.nodes[PARAGRAPH];
        const heading = schema.nodes[HEADING];
        let keepLooking = true;
        let active = false;
        doc.nodesBetween(from, to, (node, _pos) => {
            const nodeType = node.type;
            if (keepLooking &&
                (nodeType === paragraph || nodeType === heading) &&
                node.attrs.lineSpacing === this._lineSpacing) {
                keepLooking = false;
                active = true;
            }
            return keepLooking;
        });
        return active;
    };
    isEnabled = (state) => {
        return this.isActive(state) || this.execute(state);
    };
    waitForUserInput = (_state, _dispatch, _view, _event) => {
        return Promise.resolve(undefined);
    };
    executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
        return false;
    };
    cancel() {
        return null;
    }
    execute = (state, dispatch, _view) => {
        const { schema, selection } = state;
        let tr = setTextLineSpacing(state.tr.setSelection(selection), schema, this._lineSpacing);
        if (tr.docChanged) {
            // set the value of overriddenLineSpacing to true if the user override the line spacing style.
            if (selection.$head?.parent?.attrs?.lineSpacing !== this._lineSpacing) {
                const nodePos = Math.max(0, selection.head - selection.$head.parentOffset - 1);
                const node = tr.doc.nodeAt(nodePos);
                if (node) {
                    const newAttrs = {
                        ...node.attrs,
                        overriddenLineSpacing: true,
                        overriddenLineSpacingValue: this._lineSpacing
                    };
                    tr = tr.setNodeMarkup(nodePos, null, newAttrs);
                }
                dispatch?.(tr);
            }
            return true;
        }
        else {
            return false;
        }
    };
    renderLabel() {
        return null;
    }
    executeCustom = (_state, tr) => {
        return tr;
    };
    executeCustomStyleForTable = (_state, tr, _from, _to) => {
        return tr;
    };
}
