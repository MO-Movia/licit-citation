import { MarkType, Node, ResolvedPos, Schema } from 'prosemirror-model';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
export declare function applyMark(tr: Transform, _schema: Schema, markType: MarkType, attrs?: Record<string, unknown>, isCustomStyleApplied?: boolean): Transform;
export declare function addMarkWithAttributes(tr: Transform, _schema: Schema, $from: ResolvedPos, $to: ResolvedPos, markType: MarkType, attrs: Record<string, unknown>, isCustomStyleApplied: boolean): Transform;
export declare function handleTextColorMark(tr: Transform, $from: ResolvedPos, markType: MarkType, attrs: Record<string, unknown>, node: Node | null, $to: ResolvedPos, isCustomStyleApplied?: boolean): Transform;
export declare function addMarksToNode(tr: Transform, from: number, to: number, markType: MarkType, attrs: Record<string, unknown>, node: Node | null, isCustomStyleApplied?: boolean): Transform;
export declare function updateMarksAttrs(markType: MarkType, tr: Transform, state: EditorState, value: number | string): void;
export declare function updateToggleMarks(markType: MarkType, tr: Transform, state: EditorState): void;
