import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export declare class FontTypeCommand extends UICommand {
    _label: any;
    _name: string;
    _popUp: any;
    constructor(name: string);
    renderLabel: (_state: EditorState) => any;
    isEnabled: (state: EditorState) => boolean;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
    executeCustom: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    executeCustomStyleForTable: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    isActive(): boolean;
}
