import { Mark, MarkType, Node } from 'prosemirror-model';
interface Result {
    mark: Mark;
    from: {
        node: Node | null;
        pos: number;
    };
    to: {
        node: Node | null;
        pos: number;
    };
}
export declare function findNodesWithSameMark(doc: Node, from: number, to: number, markType: MarkType): Result | null;
export {};
