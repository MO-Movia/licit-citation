import { Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export type SelectionMemo = {
    schema: Schema;
    tr: Transform;
};
export declare function transformAndPreserveTextSelection(tr: Transform, schema: Schema, fn: (memo: SelectionMemo) => Transform): Transform;
