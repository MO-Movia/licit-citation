import * as React from 'react';
import { CustomButton } from './CustomButton';
export declare class ColorEditor extends React.PureComponent<{
    close: (hex: string) => void;
    hex?: string;
}> {
    render(): React.ReactElement<CustomButton>;
    private readonly _renderColor;
    private readonly _onSelectColor;
}
