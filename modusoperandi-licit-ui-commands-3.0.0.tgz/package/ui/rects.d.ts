export type Rect = {
    h: number;
    w: number;
    x: number;
    y: number;
};
export declare function isCollapsed(rect: Rect): boolean;
export declare function isIntersected(r1: Rect, r2: Rect, padding?: number): boolean;
export declare function fromXY(x: number, y: number, padding?: number): Rect;
export declare function fromHTMlElement(el: HTMLElement): Rect;
