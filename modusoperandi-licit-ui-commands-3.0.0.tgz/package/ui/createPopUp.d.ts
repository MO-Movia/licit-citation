import type { PopUpParams, ViewProps } from './PopUp';
export type PopUpHandle = {
    close: (val: any) => void;
    update: (props: Record<string, unknown>) => void;
};
export declare function showModalMask(IsChildDialog?: boolean): void;
export declare function hideModalMask(): void;
export declare function unrenderPopUp(rootId: string): void;
export declare function createPopUp(View: any, viewProps?: ViewProps, popUpParams?: PopUpParams): PopUpHandle;
