import * as React from 'react';
import type { PointerSurfaceProps } from './PointerSurface';
type CustomButtonProps = PointerSurfaceProps & {
    icon?: string | React.ReactElement | null;
    label?: string | React.ReactElement | null;
    theme?: string;
};
export declare class CustomButton extends React.PureComponent<CustomButtonProps> {
    props: CustomButtonProps;
    render(): React.ReactNode;
}
export {};
