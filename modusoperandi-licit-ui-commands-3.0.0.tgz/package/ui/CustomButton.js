import { PointerSurface } from './PointerSurface';
import * as React from 'react';
import { TooltipSurface } from './TooltipSurface';
import cx from 'classnames';
import { ThemeProvider } from './contextProvider';
export class CustomButton extends React.PureComponent {
    render() {
        const { icon, label, className, title, theme, ...pointerProps } = this.props;
        // const { theme, setTheme } = useTheme();
        const klass = cx(className, 'czi-custom-button', theme);
        return (React.createElement(ThemeProvider, { theme: theme },
            React.createElement(TooltipSurface, { tooltip: title },
                React.createElement(PointerSurface, { ...pointerProps, className: klass },
                    icon,
                    label))));
    }
}
