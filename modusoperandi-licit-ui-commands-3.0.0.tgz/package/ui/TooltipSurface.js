import * as React from 'react';
import { createPopUp } from './createPopUp';
import { atAnchorBottomCenter } from './PopUpPosition';
import { uuid } from './uuid';
class TooltipView extends React.PureComponent {
    render() {
        const { tooltip } = this.props;
        return (React.createElement("div", { className: "czi-tooltip-view czi-animation-fade-in" }, tooltip));
    }
}
export class TooltipSurface extends React.PureComponent {
    _id = uuid();
    _popUp = null;
    componentWillUnmount() {
        this._popUp?.close();
    }
    render() {
        const { tooltip, children } = this.props;
        return (React.createElement("span", { "aria-label": tooltip, className: "czi-tooltip-surface", "data-tooltip": tooltip, id: this._id, onMouseDown: tooltip && this._onMouseLeave, onMouseEnter: tooltip && this._onMouseEnter, onMouseLeave: tooltip && this._onMouseLeave, role: "tooltip" }, children));
    }
    _onMouseEnter = (e) => {
        if (e && e.target && e.target.nodeName === 'IMG' ||
            e.target && e.target.className.startsWith('czi-custom-button')) {
            if (!this._popUp) {
                const { tooltip } = this.props;
                this._popUp = createPopUp(TooltipView, { tooltip }, {
                    anchor: document.getElementById(this._id),
                    onClose: this._onClose,
                    position: atAnchorBottomCenter,
                });
            }
        }
    };
    _onMouseLeave = () => {
        this._popUp?.close();
        this._popUp = null;
    };
    _onClose = () => {
        this._popUp = null;
    };
}
